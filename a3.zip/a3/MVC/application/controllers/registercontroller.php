<?php

class RegisterController extends Controller{

	public $postObject;

	public function defaultTask(){

		$this->postObject = new User();
		$this->set('task', 'register');


	}

	public function register(){

			$this->postObject = new User();

			$data = array('fname'=>$_POST['first_name'],'lname'=>$_POST['last_name'], 'email'=>$_POST['email'], 'password'=>$_POST['password']);


			$result = $this->postObject->registerUser($data);

			$this->set('message', $result);


	}



}
