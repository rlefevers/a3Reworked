<?php
define('DEFAULT_VIEW', 'home');//set this to any page to be the default home page
define('BASE_URL', 'http://corsair.cs.iupui.edu:23651/a3/MVC/');

//database info
define('DB_HOST', 'localhost');
define('DB_USER', 'rlefever');
define('DB_PASS', 'rlefever88');
define('DB_NAME', 'rlefever_db');
