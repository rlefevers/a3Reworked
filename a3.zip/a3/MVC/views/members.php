
<?php include('elements/header.php');?>
<?php
if( is_array($user) ) {
	extract($user);?>

<div class="container">
	<div class="page-header">

<h1><?php echo $title;?></h1>
  </div>

<h2><?php echo $fname . " " . $lname;?></h2>
<h3><?php echo $email;?></h3>

</div>
<?php }?>

<?php if( is_array($users) ) {?>

<div class="container">
<div class="page-header">

<h1><?php echo $title;?></h1>
  </div>

	<?php foreach($users as $user){?>
    <h3><a href="<?php echo BASE_URL?>members/view/<?php echo $user['uID'];?>" title="<?php echo $user['first_name'] . " " . $user['last_name'];?>"></a></h3>
		<h4><?php echo $user['email']; ?></h4>
<?php }?>
</div>

<?php }?>
